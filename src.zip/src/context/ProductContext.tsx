import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  createContext,
  ReactNode,
  useContext,
  useEffect,
  useState,
} from "react";

export type Product = {
  id: string;
  name: string;
  category: string;
  image: string;
  price: number;
  stock: number;
};

type ProductContextType = {
  products: Product[];
  addProduct: (product: Product) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
};

const ProductContext = createContext<ProductContextType>({
  products: [],
  addProduct: () => {},
  updateProduct: () => {},
  deleteProduct: () => {},
});

const STORAGE_KEY = "@products";

export function ProductProvider({
  children,
}: {
  children: ReactNode;
}) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  // โหลดข้อมูลเมื่อเปิดแอป
  useEffect(() => {
    loadProducts();
  }, []);

  // บันทึกข้อมูลทุกครั้งที่มีการเปลี่ยนแปลง
  useEffect(() => {
    if (!loading) {
      saveProducts();
    }
  }, [products, loading]);

  const loadProducts = async () => {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEY);

      if (data !== null) {
        setProducts(JSON.parse(data));
      } else {
        const defaultProducts: Product[] = [
          {
            id: "1",
            name: "iPhone 15",
            category: "Mobile",
            image: "https://picsum.photos/300",
            price: 35900,
            stock: 10,
          },
          {
            id: "2",
            name: "iPad Air",
            category: "Tablet",
            image: "https://picsum.photos/301",
            price: 24900,
            stock: 5,
          },
        ];

        setProducts(defaultProducts);

        await AsyncStorage.setItem(
          STORAGE_KEY,
          JSON.stringify(defaultProducts)
        );
      }
    } catch (error) {
      console.log("Load Error :", error);
    } finally {
      setLoading(false);
    }
  };

  const saveProducts = async () => {
    try {
      await AsyncStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(products)
      );
    } catch (error) {
      console.log("Save Error :", error);
    }
  };

  const addProduct = (product: Product) => {
    setProducts((prev) => [...prev, product]);
  };

  const updateProduct = (product: Product) => {
    setProducts((prev) =>
      prev.map((item) =>
        item.id === product.id ? product : item
      )
    );
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) =>
      prev.filter((item) => item.id !== id)
    );
  };

  return (
    <ProductContext.Provider
      value={{
        products,
        addProduct,
        updateProduct,
        deleteProduct,
      }}
    >
      {children}
    </ProductContext.Provider>
  );
}

export const useProducts = () => useContext(ProductContext);