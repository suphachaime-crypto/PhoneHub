import { router } from "expo-router";
import { useState } from "react";
import {
  Alert,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
} from "react-native";
import { useProducts } from "../../context/ProductContext";

export default function AddProductScreen() {
  const { addProduct } = useProducts();

  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [image, setImage] = useState("");
  const [price, setPrice] = useState("");
  const [stock, setStock] = useState("");

  const saveProduct = () => {
    if (!name || !category || !image || !price || !stock) {
      Alert.alert("แจ้งเตือน", "กรุณากรอกข้อมูลให้ครบ");
      return;
    }

    addProduct({
      id: Date.now().toString(),
      name,
      category,
      image,
      price: Number(price),
      stock: Number(stock),
    });

    Alert.alert("สำเร็จ", "เพิ่มสินค้าเรียบร้อย");

    setName("");
    setCategory("");
    setImage("");
    setPrice("");
    setStock("");

    router.push("/(tabs)/products");
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>➕ Add Product</Text>

      <TextInput
        style={styles.input}
        placeholder="ชื่อสินค้า"
        value={name}
        onChangeText={setName}
      />

      <TextInput
        style={styles.input}
        placeholder="หมวดหมู่"
        value={category}
        onChangeText={setCategory}
      />

      <TextInput
        style={styles.input}
        placeholder="URL รูปภาพ"
        value={image}
        onChangeText={setImage}
      />

      {image !== "" && (
        <Image
          source={{ uri: image }}
          style={styles.image}
        />
      )}

      <TextInput
        style={styles.input}
        placeholder="ราคา"
        keyboardType="numeric"
        value={price}
        onChangeText={setPrice}
      />

      <TextInput
        style={styles.input}
        placeholder="จำนวนสินค้า"
        keyboardType="numeric"
        value={stock}
        onChangeText={setStock}
      />

      <TouchableOpacity
        style={styles.button}
        onPress={saveProduct}
      >
        <Text style={styles.buttonText}>
          บันทึกสินค้า
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F5F7FA",
    padding: 20,
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
    color: "#111827",
  },

  input: {
    backgroundColor: "#FFFFFF",
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
    fontSize: 16,
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },

  image: {
    width: "100%",
    height: 220,
    borderRadius: 12,
    marginBottom: 15,
    resizeMode: "cover",
    backgroundColor: "#E5E7EB",
  },

  button: {
    backgroundColor: "#2563EB",
    padding: 16,
    borderRadius: 12,
    alignItems: "center",
    marginTop: 10,
    marginBottom: 30,
  },

  buttonText: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "bold",
  },
});