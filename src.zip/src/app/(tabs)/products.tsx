import { MaterialCommunityIcons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useState } from "react";
import {
  Alert,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useProducts } from "../../context/ProductContext";

export default function ProductsScreen() {
  const { products, deleteProduct } = useProducts();

  const [search, setSearch] = useState("");

  const filteredProducts = products.filter(
    (item) =>
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.category.toLowerCase().includes(search.toLowerCase())
  );

  const confirmDelete = (id: string, name: string) => {
    Alert.alert(
      "ลบสินค้า",
      `ต้องการลบ "${name}" ใช่หรือไม่?`,
      [
        {
          text: "ยกเลิก",
          style: "cancel",
        },
        {
          text: "ลบ",
          style: "destructive",
          onPress: () => deleteProduct(id),
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>📦 Products</Text>

      <TextInput
        style={styles.search}
        placeholder="🔍 ค้นหาสินค้า..."
        value={search}
        onChangeText={setSearch}
      />

      <FlatList
        data={filteredProducts}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <Text style={styles.empty}>ไม่มีสินค้า</Text>
        }
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image
              source={{
                uri:
                  item.image && item.image.trim() !== ""
                    ? item.image
                    : "https://picsum.photos/500",
              }}
              style={styles.image}
            />

            <View style={styles.info}>
              <Text style={styles.name}>
                {item.name}
              </Text>

              <View style={styles.category}>
                <MaterialCommunityIcons
                  name="shape"
                  size={16}
                  color="#2563EB"
                />

                <Text style={styles.categoryText}>
                  {item.category}
                </Text>
              </View>

              <Text style={styles.price}>
                💰 ราคา : {item.price.toLocaleString()} บาท
              </Text>

              <Text style={styles.stock}>
                📦 คงเหลือ : {item.stock} ชิ้น
              </Text>

              <View style={styles.actions}>
                <TouchableOpacity
                  style={styles.editButton}
                  onPress={() =>
                    router.push({
                      pathname: "/edit-product",
                      params: {
                        id: item.id,
                      },
                    })
                  }
                >
                  <MaterialCommunityIcons
                    name="pencil"
                    color="#fff"
                    size={20}
                  />

                  <Text style={styles.buttonText}>
                    แก้ไข
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.deleteButton}
                  onPress={() =>
                    confirmDelete(item.id, item.name)
                  }
                >
                  <MaterialCommunityIcons
                    name="delete"
                    color="#fff"
                    size={20}
                  />

                  <Text style={styles.buttonText}>
                    ลบ
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}
      />
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F4F6F8",
    padding: 15,
  },

  title: {
    fontSize: 30,
    fontWeight: "bold",
    marginBottom: 15,
    color: "#111827",
  },

  search: {
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
    elevation: 2,
    fontSize: 16,
  },

  card: {
    backgroundColor: "#fff",
    borderRadius: 18,
    marginBottom: 18,
    overflow: "hidden",
    elevation: 4,
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 8,
    shadowOffset: {
      width: 0,
      height: 4,
    },
  },

  image: {
    width: "100%",
    height: 200,
    resizeMode: "cover",
  },

  info: {
    padding: 15,
  },

  name: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#111827",
  },

  category: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 8,
  },

  categoryText: {
    marginLeft: 6,
    color: "#2563EB",
    fontWeight: "600",
    fontSize: 15,
  },

  price: {
    marginTop: 10,
    fontSize: 17,
    fontWeight: "700",
    color: "#10B981",
  },

  stock: {
    marginTop: 6,
    fontSize: 16,
    color: "#555",
  },

  actions: {
    flexDirection: "row",
    marginTop: 18,
  },

  editButton: {
    flex: 1,
    flexDirection: "row",
    backgroundColor: "#2563EB",
    padding: 12,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 8,
  },

  deleteButton: {
    flex: 1,
    flexDirection: "row",
    backgroundColor: "#EF4444",
    padding: 12,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 8,
  },

  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    marginLeft: 6,
    fontSize: 15,
  },

  empty: {
    textAlign: "center",
    marginTop: 60,
    fontSize: 18,
    color: "#9CA3AF",
  },
});
